<!-- Bootstrap -->
        <link href="<? echo base_url(); ?>theme/admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="<? echo base_url(); ?>theme/admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="<? echo base_url(); ?>theme/admin/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="<? echo base_url(); ?>theme/admin/assets/styles.css" rel="stylesheet" media="screen">
        <link href="<? echo base_url(); ?>theme/admin/assets/DT_bootstrap.css" rel="stylesheet" media="screen">        
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
<style type="text/css">
@font-face {
    font-family: 'CSChatThai';
    src: url('<? echo base_url(); ?>theme/font/CSChatThai.eot');
    src: url('<? echo base_url(); ?>theme/font/CSChatThai.eot?#iefix') format('embedded-opentype'),
         url('<? echo base_url(); ?>theme/font/CSChatThai.woff') format('woff'),
         url('<? echo base_url(); ?>theme/font/CSChatThai.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
}
body{ 
font-family:CSChatThai ,Tahoma;
font-size:20px;
}    
</style>        
        <script src="<? echo base_url(); ?>theme/admin/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <!--/.fluid-container-->
        <script src="<? echo base_url(); ?>theme/admin/vendors/jquery-1.9.1.min.js"></script>
        <script src="<? echo base_url(); ?>theme/admin/bootstrap/js/bootstrap.min.js"></script>
        <script src="<? echo base_url(); ?>theme/admin/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="<? echo base_url(); ?>theme/admin/assets/scripts.js"></script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>    
<script src="<? echo base_url(); ?>theme/admin/assets/DT_bootstrap.js"></script>          