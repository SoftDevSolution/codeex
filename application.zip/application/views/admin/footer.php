<footer>
    <p>Copyright © 2021 Concept. All rights reserved.</p>
</footer>