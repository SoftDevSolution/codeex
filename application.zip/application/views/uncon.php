<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CODEEX.co.th is under construction</title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,900">

    <link rel="stylesheet" href="<? echo base_url(); ?>theme/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<? echo base_url(); ?>theme/css/uncon_style.css" type="text/css">
    <link rel="stylesheet" href="<? echo base_url(); ?>theme/css/common.css" type="text/css">

</head>
<body>

    <div id="hero-image">
      <img src="<? echo base_url(); ?>theme/images/mad-designer.png" alt="Mad Designer at work" title="Mad Designer at work">
    </div>
    <div class="container">

      <div class="row">
        <div class="col-xs-12 col-md-12 col-lg-12">
          <h1>Sorry, we're doing some work on the site</h1>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12 col-md-8 col-md-offset-2 col-lg-offset-2 col-lg-8">
          <p class="content">Thank you for being patient. We are doing some work on the site and will be back shortly.</p>
        </div>
      </div>

      <div class="row" id="social">
        <div class="col-xs-12 col-md-12 col-lg-12">
          
        </div>
      </div>

    </div>

</body>
</html>