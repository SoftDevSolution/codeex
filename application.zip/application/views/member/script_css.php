<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/vendor/bootstrap/css/bootstrap.min.css">
<link href="<? echo base_url(); ?>theme/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/libs/css/style.css">
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/vendor/vector-map/jqvmap.css">
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/vendor/jvectormap/jquery-jvectormap-2.0.2.css">
<link rel="stylesheet" href="<? echo base_url(); ?>theme/assets/vendor/fonts/flag-icon-css/flag-icon.min.css">

<style>
    .empty_data {
        padding : 60px 10px;
    }
    .img_thumnail {
        max-width: 120px;
    }
</style>