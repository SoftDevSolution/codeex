<!-- jquery 3.3.1 js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstrap bundle js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- chartjs js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
    <script src="<? echo base_url(); ?>theme/assets/vendor/charts/charts-bundle/chartjs.js"></script>
   
    <!-- main js-->
    <script src="<? echo base_url(); ?>theme/assets/libs/js/main-js.js"></script>
    <!-- jvactormap js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<? echo base_url(); ?>theme/assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- sparkline js-->
    <script src="<? echo base_url(); ?>theme/assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <script src="<? echo base_url(); ?>theme/assets/vendor/charts/sparkline/spark-js.js"></script>
     <!-- dashboard sales js-->
    <script src="<? echo base_url(); ?>theme/assets/libs/js/dashboard-sales.js"></script>